
package main;

import view.NewJFrame;

public class Main {
    public static void main(String args[]){
        NewJFrame janela = new NewJFrame();
        janela.setVisible(true);
    } 
    
}
