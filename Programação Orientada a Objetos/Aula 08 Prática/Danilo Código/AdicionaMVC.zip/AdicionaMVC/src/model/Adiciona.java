
package model;

public class Adiciona {
    public double calcula(double x, double y){
        return x+y;
    }
}
