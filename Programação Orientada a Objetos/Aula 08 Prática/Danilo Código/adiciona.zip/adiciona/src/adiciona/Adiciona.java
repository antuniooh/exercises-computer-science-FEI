
package adiciona;

public class Adiciona {

    public static void main(String[] args) {
        Janela j = new Janela();
        j.setVisible(true);
    }
    
}
