package model;

public abstract class Calculadora {
    public abstract double calcula(double x, double y);
    double x;
    double y;
}




