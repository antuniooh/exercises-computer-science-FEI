
package model;

/**
 *
 * @author dperico
 */
public class Multiplica extends Calculadora{
    @Override
    public double calcula(double x, double y){
        return x*y;
    }
}
